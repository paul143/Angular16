import { Component } from '@angular/core';
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-lazy-loading-example';
  constructor(private router:Router) { }

  openshop(){
//alert("pa");
this.router.navigate(['shop']);

  }
  openshopconfirm(){
    //alert("pa");
    this.router.navigate(['shop/confirm']);
    
      }
      openshopcheckout(){
        //alert("pa");
        this.router.navigate(['shop/checkout']);
        
          }


}
